
<div class="avatar av-l chatify-d-flex"></div>
<p class="info-name"><?php echo e(config('chatify.name')); ?></p>
<div class="messenger-infoView-btns">
    <a href="#" class="danger delete-conversation">Delete Conversation</a>
</div>

<div class="messenger-infoView-shared">
    <p class="messenger-title"><span>Shared Photos</span></p>
    <div class="shared-photos-list"></div>
</div>
<?php /**PATH D:\youssef-files\chatapp\resources\views/vendor/Chatify/layouts/info.blade.php ENDPATH**/ ?>